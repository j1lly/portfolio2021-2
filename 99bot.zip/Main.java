class Main {
  public static void main(String[] args) {
    int bottles = 99;
    for (int i=0; i<99; i++) {
      System.out.println(bottles + " bottles of coke");
      bottles -= 1;
    }
  }
}