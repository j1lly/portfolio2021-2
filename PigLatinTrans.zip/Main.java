class Main {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);

    //welcome
    System.out.println("Welcome to Pig Latin Translator! Please enter a word of your choosing.");
    
    //ask for word
    String word = sc.nextLine();
    
    //show user word
    System.out.println("Your word is: " + word);

    //save first letter
    char firstChar = word.charAt(0);
    System.out.println("First letter: " + firstChar);
    
    //remove first letter
    word = word.substring(1, word.length());
    System.out.println("First letter removed: " + word);
    
    //append "ay"
    word = word + firstChar + "ay";

    //show full translation
    System.out.println("Full PigLatin: " + word);
  }
}